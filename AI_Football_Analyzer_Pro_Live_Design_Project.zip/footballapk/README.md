# AI Football Analyzer Pro — Android project

A polished Android Studio project with a dark navy-and-gold interface, football fixtures/results, league standings, and a manual team-comparison workspace.

## Live data setup
1. Create your own token through the official [football-data.org website](https://www.football-data.org/).
2. Build and open the app, then scroll to **Connect live football data**. Paste your token and tap **Use Token**.
3. Open **Fixtures** to select a date and optionally filter by competition. Open **Tables** to load standings.
4. The token is held in app memory for the current session only; it is not embedded in this project. You will need to enter it again after restarting the app.

Live fixtures, scores and standings depend on the provider's coverage, subscription and request limits. This connection does not supply detailed live corner/card stats; those fields remain manual inputs in the analyzer.

## Build an APK
1. Install Android Studio on a computer.
2. Open the `footballapk` folder in Android Studio.
3. Allow Gradle sync and install any requested Android SDK (compile SDK 35).
4. Choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Android Studio will show the generated APK path, usually `app/build/outputs/apk/debug/app-debug.apk`.
6. Transfer that APK to your Android phone and install it.

## Important limitations
- This ZIP is the Android project source, not a precompiled APK.
- An API token is required for live data. Never share your token. For a public production app, use a secure backend rather than distributing a private API token in an APK.
- The analyzer uses manually entered averages and a simple statistical model. It is informational, not a guarantee of future results. No odds or betting features are included.
