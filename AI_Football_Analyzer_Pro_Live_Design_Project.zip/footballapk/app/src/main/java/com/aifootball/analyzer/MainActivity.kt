package com.aifootball.analyzer

import android.app.Activity
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URI
import java.net.URL

class MainActivity : Activity() {
    @Suppress("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val webView = WebView(this)
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.webViewClient = WebViewClient()
        webView.webChromeClient = WebChromeClient()
        webView.addJavascriptInterface(ApiBridge(this, webView), "FootballBridge")
        setContentView(webView)
        webView.loadUrl("file:///android_asset/index.html")
    }

    private class ApiBridge(private val activity: Activity, private val webView: WebView) {
        @JavascriptInterface
        fun getJson(urlText: String, token: String, requestId: Int) {
            Thread {
                var status = 0
                var body = ""
                var connection: HttpURLConnection? = null
                try {
                    val uri = URI(urlText)
                    require(uri.scheme == "https" && uri.host == "api.football-data.org" && uri.path.startsWith("/v4/")) {
                        "Only the official football-data.org v4 API is allowed."
                    }
                    require(token.isNotBlank() && token.length <= 500) { "Enter a valid API token." }
                    connection = URL(urlText).openConnection() as HttpURLConnection
                    connection.requestMethod = "GET"
                    connection.connectTimeout = 12000
                    connection.readTimeout = 15000
                    connection.setRequestProperty("X-Auth-Token", token)
                    connection.setRequestProperty("Accept", "application/json")
                    status = connection.responseCode
                    val stream = if (status in 200..299) connection.inputStream else connection.errorStream
                    body = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: "{}"
                } catch (e: Exception) {
                    status = 0
                    body = JSONObject().put("message", e.message ?: "Network request failed.").toString()
                } finally {
                    connection?.disconnect()
                }
                val safeBody = JSONObject.quote(body)
                activity.runOnUiThread {
                    webView.evaluateJavascript("window.handleApiResponse($requestId,$status,$safeBody)", null)
                }
            }.start()
        }
    }
}
